import requests
import sys



# read all subdomains
file = open("hosts.txt")
# read all content
content = file.read()
# split by new lines
subdomains = content.splitlines()

#To seperate the string elements with ',' seperator
subdomain1 =[]
for i in range(len(subdomains)):
    
    sub = subdomains[i].split(',')
    subdomain1.insert(i,sub)

#extracting the urls
sub1 = []
for i in range(len(subdomain1)):
    dub = subdomain1[i].pop(0)
    sub1.insert(i,dub)
        
    
    
   
for link in sub1:
    
   # construct the url
   url = f"http://{link}"
   
   try:
        # if this raises an ERROR, that means the subdomain does not exist
        r = requests.get(url)
        
        if(r.status_code==403 or r.status_code==404):
          continue
        else:
          print(url,r.status_code)
          f = open(r"/home/kali/Desktop/checker.txt","a")
          f.write(""+url+" "+str(r.status_code)+"\n")
   except requests.ConnectionError:
        # if the subdomain does not exist, just pass, print nothing
        pass
   
        
