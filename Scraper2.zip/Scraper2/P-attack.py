import urllib
import urllib.request,urllib.parse,urllib.error
from bs4 import BeautifulSoup


req=urllib.request.urlopen('https://github.com/noobsecurity/sample_data/blob/master/log.txt')
soup=BeautifulSoup(req,"html.parser")
data=soup.findAll(text=True)

add=0
c=0
for i in data:
    temp=i.split()
    
    if 'P-Attack-Confirmation:' in temp:
        print(temp[1])
        c=c+1
        add=add+float(temp[1])

print(c)
print(add)
average=add/c
print("Attack Confidence:{}".format(average))

