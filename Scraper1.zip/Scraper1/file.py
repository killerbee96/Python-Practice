import urllib.request
from bs4 import BeautifulSoup


req=urllib.request.urlopen('https://github.com/noobsecurity/sample_data/blob/master/log.txt')
soup=BeautifulSoup(req,"html.parser")
data=soup.findAll(text=True)

for i in data:
    temp=i.split()
    if 'From' in temp:
        print(temp[1])

 
